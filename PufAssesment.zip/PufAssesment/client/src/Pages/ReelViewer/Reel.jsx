import React from 'react'

const Reel = () => {
  return (
    <div>Reel</div>
  )
}

export default Reel