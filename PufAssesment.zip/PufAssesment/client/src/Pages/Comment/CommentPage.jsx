import React from 'react'

const CommentPage = () => {
  return (
    <div>
        
    </div>
  )
}

export default CommentPage