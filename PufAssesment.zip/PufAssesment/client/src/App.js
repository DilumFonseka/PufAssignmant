import { Routes } from "react-router";
import Routers from "./Pages/Router/Routers";



function App() {
  return (
    <div className="">
      
<Routers/>

    </div>
  );
}

export default App;
