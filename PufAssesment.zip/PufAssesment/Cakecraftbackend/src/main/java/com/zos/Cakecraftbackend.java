package com.zos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cakecraftbackend {

	public static void main(String[] args) {
		SpringApplication.run(Cakecraftbackend.class, args);
	}

}
