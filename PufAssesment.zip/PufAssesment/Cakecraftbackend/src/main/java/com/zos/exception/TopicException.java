package com.zos.exception;

public class TopicException extends Exception {

    public TopicException(String message) {
        super(message);

    }

}