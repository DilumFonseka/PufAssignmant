package com.zos.exception;

public class LearningPlanException extends Exception {
    public LearningPlanException(String message) {
        super(message);

    }

}
